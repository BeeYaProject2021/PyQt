import tensorflow as tf
import numpy as np
from tensorflow import keras
from tensorflow.keras import layers, models, optimizers

import socket, time
ServerSocket = socket.socket()
ServerSocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
host = '140.136.151.88'
port = 48766

try:
    ServerSocket.bind((host, port))
except socket.error as e:
    print(str(e))

print('Waiting for a Connection..')
ServerSocket.listen(1)
conn, address = ServerSocket.accept()
print('Connected to: ' + address[0] + ':' + str(address[1]))

gpu_options = tf.compat.v1.GPUOptions(per_process_gpu_memory_fraction=0.25)
sess = tf.compat.v1.Session(config=tf.compat.v1.ConfigProto(gpu_options=gpu_options))
print("CNN TRAINING START!\n\n")
uid = '6ebd2db34c9b4602a75ca9efb57e2d6c'
file_name = 'data.npz'
train = np.load('/home/b04/桌面/Github/Api/api/media/6ebd2db34c9b4602a75ca9efb57e2d6c' + '/' + file_name)
train_images, train_labels = train['train_img'], train['train_lab']
test_images, test_labels = train['test_img'], train['test_lab']
train_images = train_images / 255.0
test_images = test_images / 255.0

model = models.Sequential()

class CustomCallback(keras.callbacks.Callback):
    global conn
    def on_train_end(self, logs=None):
        print("\n----Training Done!----")
        conn.send(str.encode("over\r\n"))
        conn.close()
    def on_epoch_end(self, epoch, logs=None):
        time.sleep(0.02)
        conn.send(str.encode(f'#{epoch+1:02d}#{logs["accuracy"]:015.10f}#{logs["val_accuracy"]:015.10f}#{logs["loss"]:015.10f}#{logs["val_loss"]:015.10f}\r\n'))
    def on_train_batch_end(self, batch, logs=None):
        time.sleep(0.02)
        conn.send(str.encode(f'@{batch+1:02d}@{logs["accuracy"]:015.10f}@{logs["loss"]:015.10f}\r\n'))

model.add(layers.Input(shape=(100, 100, 3)))
model.add(layers.Conv2D(32, 3, padding='same', activation='relu'))
model.add(layers.MaxPooling2D(pool_size=2))
model.add(layers.Conv2D(64, 3, padding='same', activation='relu'))
model.add(layers.MaxPooling2D(pool_size=2))
model.add(layers.Conv2D(128, 3, padding='same', activation='relu'))
model.add(layers.MaxPooling2D(pool_size=2))
model.add(layers.Flatten())
model.add(layers.Dense(1024, activation='relu'))
model.add(layers.Dense(512, activation='relu'))
model.add(layers.Dense(150, activation='softmax'))
opt=optimizers.Adam(lr=0.001)
model.compile(optimizer=opt,loss='sparse_categorical_crossentropy',metrics=['accuracy'])
model.summary()
model.fit(train_images, train_labels, batch_size=16, epochs=10, callbacks=[CustomCallback()], validation_data=(test_images, test_labels))
model.save('/home/b04/桌面/Github/Api/api/media/6ebd2db34c9b4602a75ca9efb57e2d6c' + '/')
